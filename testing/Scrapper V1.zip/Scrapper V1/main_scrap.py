# LEGACY
from __future__ import annotations
import json
import csv
import argparse
from collections import Counter
from typing import List, Dict, Tuple, Optional
from datetime import datetime, timezone
from urllib.parse import urlparse, urlunparse, parse_qsl, urlencode

from config import get_otx_api_key
from auto_OTX import automation_OTX
from storage import init_db, filter_new, save_new

# -------- Normalization helpers (lightweight, stdlib only) --------

_TYPE_MAP = {
    # Common OTX variants -> our canonical names
    "filehash-md5": "hash-md5",
    "filehash-sha1": "hash-sha1",
    "filehash-sha256": "hash-sha256",
    "md5": "hash-md5",
    "sha1": "hash-sha1",
    "sha256": "hash-sha256",
}

_TRACKER_PARAMS = {"utm_source","utm_medium","utm_campaign","utm_term","utm_content","utm_id",
                   "gclid","fbclid","mc_cid","mc_eid","msclkid"}

def _canon_type(t: str) -> str:
    if not t: return "unknown"
    t = t.strip().lower()
    return _TYPE_MAP.get(t, t)

def _normalize_domain(indicator: str) -> str:
    # Lowercase host parts; keep as-is if it already looks like a pure domain
    return indicator.strip().lower()

def _normalize_url(indicator: str) -> str:
    try:
        u = urlparse(indicator.strip())
        # lowercase scheme and host, drop common tracker query params
        scheme = (u.scheme or "http").lower()
        netloc = u.netloc.lower()
        q = [(k, v) for (k, v) in parse_qsl(u.query, keep_blank_values=True) if k not in _TRACKER_PARAMS]
        return urlunparse((scheme, netloc, u.path or "", u.params, urlencode(q, doseq=True), ""))  # strip fragment
    except Exception:
        return indicator.strip()

def normalize_record(r: Dict) -> Dict:
    t = _canon_type(r.get("type", ""))
    val = r.get("indicator", "")
    if t == "domain":
        val = _normalize_domain(val)
    elif t == "url":
        val = _normalize_url(val)
    elif t.startswith("hash-"):
        val = val.strip().lower()
    elif t in ("ipv4","ipv6"):
        val = val.strip()
    nr = dict(r)
    nr["type"] = t
    nr["indicator"] = val
    return nr

# -------- Export helpers --------

def write_json(recs: List[Dict], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(recs, f, indent=2, ensure_ascii=False)

def write_csv(recs: List[Dict], path: str) -> None:
    fields = ["indicator", "type", "source", "source_url", "first_seen", "pulse_name", "pulse_id"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in recs:
            ctx = r.get("context", {}) or {}
            w.writerow({
                "indicator": r.get("indicator", ""),
                "type": r.get("type", ""),
                "source": r.get("source", ""),
                "source_url": r.get("source_url", ""),
                "first_seen": r.get("first_seen", ""),
                "pulse_name": ctx.get("pulse_name", ""),
                "pulse_id": ctx.get("pulse_id", "")
            })

def summarize_by_type(recs: List[Dict]) -> Dict[str, int]:
    return dict(sorted(Counter(r.get("type", "unknown") for r in recs).items(),
                       key=lambda kv: (-kv[1], kv[0])))

def write_report(all_recs: List[Dict], exported: List[Dict], path: str,
                 pages: int, since: Optional[str]) -> None:
    pulled = len(all_recs)
    exported_n = len(exported)
    pulled_by = summarize_by_type(all_recs)
    exported_by = summarize_by_type(exported)

    # time bounds (if available)
    def _ts(r): 
        try: return datetime.fromisoformat(r.get("first_seen","").replace("Z","+00:00"))
        except: return None
    times = [t for t in map(_ts, all_recs) if t]
    first_ts = min(times).isoformat() if times else "n/a"
    last_ts  = max(times).isoformat() if times else "n/a"

    with open(path, "w", encoding="utf-8") as f:
        f.write("# IoC Scrape Report (OTX)\n")
        f.write(f"Pages processed: {pages}\n")
        f.write(f"Since filter:   {since or 'none'}\n")
        f.write(f"Pulled total:   {pulled}\n")
        f.write(f"Exported:       {exported_n}\n")
        f.write(f"First/Last seen in pulled: {first_ts} .. {last_ts}\n\n")
        f.write("Pulled by type:\n")
        for k,v in pulled_by.items(): f.write(f"  - {k}: {v}\n")
        f.write("\nExported by type:\n")
        for k,v in exported_by.items(): f.write(f"  - {k}: {v}\n")

# -------- Date filter --------

def parse_since(s: str) -> datetime:
    """
    Accepts 'YYYY-MM-DD' or full ISO like '2025-09-21T00:00:00Z'.
    Returns aware UTC datetime.
    """
    s = s.strip()
    try:
        if "T" in s:
            # normalize trailing Z
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        else:
            dt = datetime.fromisoformat(s + "T00:00:00+00:00")
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        raise argparse.ArgumentTypeError(f"Invalid --since value: {s}")

def filter_since(recs: List[Dict], cutoff: datetime) -> List[Dict]:
    out = []
    for r in recs:
        ts = r.get("first_seen", "")
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except Exception:
            # if missing/invalid timestamp, keep it (or change to 'continue' if you prefer strict)
            out.append(r)
            continue
        if dt >= cutoff:
            out.append(r)
    return out

# -------- Main --------

def main():
    ap = argparse.ArgumentParser(description="Scrape OTX IoCs (subscribed pulses) with persistent dedup.")
    ap.add_argument("--pages", type=int, default=1, help="How many pages of subscribed pulses to fetch (default: 1).")
    ap.add_argument("--out", default="otx_iocs", help="Base filename for outputs (default: otx_iocs).")
    ap.add_argument("--all", action="store_true",
                    help="Export all fetched IoCs (default exports only NEW ones).")
    ap.add_argument("--since", type=parse_since, default=None,
                    help="Only export IoCs with first_seen on/after this date (YYYY-MM-DD or ISO).")
    ap.add_argument("--report", action="store_true",
                    help="Write a text report alongside outputs.")
    args = ap.parse_args()

    json_out = f"{args.out}.json"
    csv_out  = f"{args.out}.csv"
    report_out = f"{args.out}_report.txt"

    # 1) key + db
    api_key = get_otx_api_key()
    init_db()

    # 2) fetch
    recs = automation_OTX(api_key, max_pulse_pages=args.pages)

    # 3) normalize (light)
    recs = [normalize_record(r) for r in recs]

    # 4) figure out NEW (for persistence) and optionally apply --since to export set
    new_recs = filter_new(recs)

    to_export = recs if args.all else new_recs
    if args.since:
        to_export = filter_since(to_export, args.since)

    # 5) write outputs
    write_json(to_export, json_out)
    write_csv(to_export, csv_out)

    # 6) persist NEW (so we don't repeat on next run)
    save_new(new_recs)

    # 7) summaries
    print(f"[main_scrap] Pages: {args.pages}")
    print(f"[main_scrap] Pulled total: {len(recs)}  | New: {len(new_recs)}  | Exported: {len(to_export)}")
    print(f"[main_scrap] Wrote → {json_out}  &  {csv_out}")
    print(f"[summary] Pulled by type:   {summarize_by_type(recs)}")
    print(f"[summary] Exported by type: {summarize_by_type(to_export)}")
    if args.all:
        print("[note] --all used: exporting ALL fetched IoCs (not just NEW).")
    if args.since:
        print(f"[note] --since used: only IoCs on/after {args.since.isoformat()} were exported.")
    if args.report:
        write_report(recs, to_export, report_out, args.pages,
                     args.since.isoformat() if args.since else None)
        print(f"[report] Wrote → {report_out}")

if __name__ == "__main__":
    main()
