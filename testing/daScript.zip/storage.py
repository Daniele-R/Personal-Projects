# storage/state.py
from __future__ import annotations
import json
import sqlite3
from datetime import datetime
from typing import Dict, List

DB_PATH = "ioc_state.db"

def _conn():
    return sqlite3.connect(DB_PATH)

def init_db():
    conn = _conn()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS iocs (
            key TEXT PRIMARY KEY,           -- e.g., "url:https://ex.tld/path"
            type TEXT NOT NULL,             -- ipv4|domain|url|hash-...
            indicator TEXT NOT NULL,        -- original value
            source TEXT NOT NULL,           -- e.g., "otx"
            first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL,
            context TEXT                    -- JSON blob (pulse_name, pulse_id, etc.)
        )
    """)
    conn.commit()
    conn.close()

def make_key(ioc: Dict) -> str:
    return f"{ioc['type'].lower()}:{ioc['indicator'].strip().lower()}"

def filter_new(iocs: List[Dict]) -> List[Dict]:
    """Return only records not already in DB (by key)."""
    if not iocs:
        return []
    conn = _conn()
    cur = conn.cursor()
    new_recs = []
    for rec in iocs:
        key = make_key(rec)
        cur.execute("SELECT 1 FROM iocs WHERE key = ?", (key,))
        if cur.fetchone() is None:
            new_recs.append(rec)
        else:
            # Optional: update last_seen for known IoCs
            cur.execute("UPDATE iocs SET last_seen = ? WHERE key = ?", (datetime.utcnow().isoformat(), key))
    conn.commit()
    conn.close()
    return new_recs

def save_new(iocs: List[Dict]):
    """Insert new IoCs (idempotent with PRIMARY KEY)."""
    if not iocs:
        return
    conn = _conn()
    cur = conn.cursor()
    now = datetime.utcnow().isoformat()
    for rec in iocs:
        key = make_key(rec)
        cur.execute("""
            INSERT OR IGNORE INTO iocs (key, type, indicator, source, first_seen, last_seen, context)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            key,
            rec["type"],
            rec["indicator"],
            rec.get("source", "unknown"),
            rec.get("first_seen", now),
            rec.get("last_seen", now),
            json.dumps(rec.get("context", {}))
        ))
    conn.commit()
    conn.close()