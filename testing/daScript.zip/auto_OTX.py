# sources/otx.py
from __future__ import annotations
import time
from typing import Dict, Any, List
from datetime import datetime
import requests

OTX_BASE = "https://otx.alienvault.com/api/v1"

def _headers(api_key: str) -> Dict[str, str]:
    return {
        "X-OTX-API-KEY": api_key,
        "User-Agent": "ioc-scraper-quickwin/0.3"
    }

def _get_subscribed_pulses(api_key: str, page: int = 1) -> Dict[str, Any]:
    url = f"{OTX_BASE}/pulses/subscribed?page={page}"
    r = requests.get(url, headers=_headers(api_key), timeout=30)
    if r.status_code == 401:
        raise RuntimeError("OTX 401 Unauthorized. Check your API key.")
    r.raise_for_status()
    return r.json()

def _get_pulse_indicators(api_key: str, pulse_id: str, page: int = 1) -> Dict[str, Any]:
    url = f"{OTX_BASE}/pulses/{pulse_id}/indicators?page={page}"
    r = requests.get(url, headers=_headers(api_key), timeout=30)
    r.raise_for_status()
    return r.json()

def automation_OTX(api_key: str, *, max_pulse_pages: int = 1) -> List[Dict[str, Any]]:
    """
    Fetch IoCs from your subscribed OTX pulses (first N pages).
    Returns a list of IoC dicts (no file I/O here).
    """
    if not api_key or not api_key.strip():
        raise ValueError("auto_OTX(): api_key is empty")

    collected: List[Dict[str, Any]] = []
    seen_keys = set()  # dedup within this run

    pulse_page = 1
    while pulse_page <= max_pulse_pages:
        data = _get_subscribed_pulses(api_key, page=pulse_page)
        results = data.get("results", [])
        if not results:
            break

        for p in results:
            pulse_id = p.get("id") or p.get("pulse_id")
            pulse_name = p.get("name", "")
            if not pulse_id:
                continue

            ind_page = 1
            while True:
                inds = _get_pulse_indicators(api_key, pulse_id, page=ind_page)
                iresults = inds.get("results", [])
                if not iresults:
                    break

                for i in iresults:
                    i_type = i.get("type")       # e.g., ipv4, domain, url, FileHash-SHA256
                    value  = i.get("indicator")  # indicator string
                    if not i_type or not value:
                        continue

                    key = f"{i_type.lower()}:{value.strip().lower()}"
                    if key in seen_keys:
                        continue
                    seen_keys.add(key)

                    rec = {
                        "indicator": value,
                        "type": i_type.lower(),
                        "source": "otx",
                        "source_url": p.get("url") or "",
                        "first_seen": i.get("created") or datetime.utcnow().isoformat(timespec="seconds") + "Z",
                        "context": {
                            "pulse_name": pulse_name,
                            "pulse_id": pulse_id
                        }
                    }
                    collected.append(rec)

                if not inds.get("next_page"):
                    break
                ind_page += 1

        if not data.get("next_page"):
            break
        pulse_page += 1
        time.sleep(0.8)  # polite pause

    return collected