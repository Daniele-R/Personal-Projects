# config.py
from __future__ import annotations
import os
from typing import Optional

CONFIG_FILE = "config.toml"

def _load_from_toml(path: str = CONFIG_FILE) -> Optional[str]:
    if not os.path.exists(path):
        return None
    try:
        import tomllib  # Python 3.11+
        with open(path, "rb") as fh:
            data = tomllib.load(fh)
        return (data.get("otx") or {}).get("api_key")
    except Exception:
        return None

def get_otx_api_key(cli_key: Optional[str] = None) -> str:
    """Priority: CLI (if you add it later) > env OTX_API_KEY > config.toml"""
    key = cli_key or os.getenv("OTX_API_KEY") or _load_from_toml()
    if not key or not key.strip():
        raise RuntimeError(
            "OTX API key not found. Provide via env OTX_API_KEY or config.toml:\n"
            "[otx]\napi_key = \"YOUR_KEY\""
        )
    return key.strip()